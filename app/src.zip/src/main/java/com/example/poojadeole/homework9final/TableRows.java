package com.example.poojadeole.homework9final;

/**
 * Created by poojadeole on 11/19/17.
 */

public class TableRows {
    String title;
    String header;
}
