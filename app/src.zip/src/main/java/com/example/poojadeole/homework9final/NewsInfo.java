package com.example.poojadeole.homework9final;

/**
 * Created by poojadeole on 11/21/17.
 */

public class NewsInfo {
    String ntitle;
    String nauthor;
    String nlink;
    String ndate;
}
